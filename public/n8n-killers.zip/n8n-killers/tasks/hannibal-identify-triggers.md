---
task: Identify Triggers
agent: hannibal
elicit: false
---

# hannibal-identify-triggers

Hannibal identifica e documenta todos os triggers do workflow n8n, com seus parâmetros completos para auxiliar a migração por Ghostface.

## Inputs

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `workflowJson` | object | JSON do workflow parseado |

## Execução

1. Localizar todos os nodes de trigger no JSON
2. Para cada trigger, documentar:

### Webhook Trigger
```yaml
type: webhook
path: /my-webhook-path
method: POST | GET | PUT | DELETE
authentication: none | headerAuth | basicAuth
responseMode: onReceived | lastNode
options:
  rawBody: boolean
  ipWhitelist: [...]
```

### Schedule Trigger
```yaml
type: schedule
rule:
  interval: cron | everyMinute | everyHour | everyDay | everyWeek | everyMonth
  cronExpression: "0 9 * * 1-5"  # se cron
  timezone: "America/Sao_Paulo"
```

### Manual Trigger
```yaml
type: manual
notes: "Usado apenas para testes — substituir por schedule em prod"
```

### Email Trigger (IMAP)
```yaml
type: email
protocol: imap
host: imap.gmail.com
port: 993
mailbox: INBOX
filters:
  sender: "alerts@system.com"
  subject: "ALERT:"
```

## Output

```yaml
triggers:
  - id: "trigger-uuid"
    name: "Receive Customer Webhook"
    type: webhook
    config: { ... }
    migrationNotes: "Recriar como webhook no sistema-alvo. Atualizar URL no sistema-fonte."
```
