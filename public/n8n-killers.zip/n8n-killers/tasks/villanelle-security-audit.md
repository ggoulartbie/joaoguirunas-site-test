---
task: Security Audit
agent: villanelle
elicit: false
---

# villanelle-security-audit

Villanelle realiza auditoria completa de segurança da automação, verificando exposição de credenciais, validação de payloads e conformidade com boas práticas.

## Checklist de Auditoria

### Credenciais & Secrets
- [ ] Nenhuma credencial hardcoded em nodes ou expressões
- [ ] Todas as chaves armazenadas em credential objects ou env vars
- [ ] Campos sensíveis mascarados em logs (`password`, `token`, `secret`, `key`)
- [ ] Credenciais de prod isoladas de dev/staging
- [ ] Tokens OAuth2 com refresh configurado
- [ ] API keys com data de expiração documentada

### Webhooks
- [ ] Todos os webhooks têm autenticação (Bearer, API Key ou HMAC)
- [ ] HMAC verification implementado quando provider suporta
- [ ] Payloads validados antes de processar (tipo, campos obrigatórios)
- [ ] URL de webhook não exposta publicamente sem necessidade
- [ ] Rate limiting configurado para endpoints de webhook

### Dados
- [ ] PII (dados pessoais) não logados desnecessariamente
- [ ] Dados sensíveis não transitam por sistemas intermediários sem criptografia
- [ ] Resposta de erros não expõe detalhes internos do sistema

### Acesso
- [ ] RBAC configurado: quem pode ver/editar cada workflow
- [ ] API keys com mínimo de permissões necessárias (principle of least privilege)
- [ ] Revogação de credenciais antigas (do n8n original) planejada

## Formato do Relatório

```yaml
securityAudit:
  date: "2026-04-14"
  auditor: villanelle
  result: PASS | FAIL | CONDITIONAL

  findings:
    - severity: CRITICAL | HIGH | MEDIUM | LOW
      category: credentials | webhook | data | access
      description: "..."
      recommendation: "..."
      status: OPEN | RESOLVED

  approved: true | false
  conditions: []  # Se CONDITIONAL
```
