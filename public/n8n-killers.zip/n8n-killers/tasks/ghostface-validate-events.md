---
task: Validate Events
agent: ghostface
elicit: false
---

# ghostface-validate-events

Ghostface testa e valida o sistema de eventos: delivery de webhooks, idempotência, autenticação e comportamento sob condições adversas.

## Testes Executados

### 1. Happy Path
- Enviar payload válido para cada webhook
- Confirmar recebimento e processamento correto
- Verificar resposta 200 retornada ao sender

### 2. Autenticação
```bash
# Teste: signature válida → deve aceitar
curl -X POST https://hook.example.com/webhook/test \
  -H "X-Signature: sha256={valid_hmac}" \
  -H "Content-Type: application/json" \
  -d '{"event": "test", "data": {}}'

# Teste: signature inválida → deve rejeitar com 401
curl -X POST https://hook.example.com/webhook/test \
  -H "X-Signature: sha256=invalid_signature" \
  -H "Content-Type: application/json" \
  -d '{"event": "test", "data": {}}'
```

### 3. Payload Inválido
```bash
# Teste: campo obrigatório ausente → deve retornar 400
curl -X POST https://hook.example.com/webhook/test \
  -d '{"wrong": "payload"}'
```

### 4. Idempotência
```bash
# Enviar o mesmo evento_id duas vezes
# Segunda execução deve ser ignorada silenciosamente
```

### 5. Schedule Accuracy
- Verificar que o cron dispara no horário configurado
- Verificar timezone correta
- Monitorar por pelo menos 2 ciclos

### 6. Delivery Reliability
- Simular timeout do sistema-alvo
- Verificar se sender faz retry (quando suportado)
- Confirmar que eventos não são perdidos

## Output

```yaml
eventValidation:
  webhooks:
    - name: "Customer Created"
      happyPath: PASS
      authValidation: PASS
      payloadValidation: PASS
      idempotency: PASS
      overall: PASS
  schedules:
    - name: "Daily Report"
      accuracy: PASS
      timezone: PASS
      overall: PASS
  summary: ALL PASS
```
