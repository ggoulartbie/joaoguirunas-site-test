---
task: Assess Migration
agent: bourne
elicit: true
---

# bourne-assess-migration

Bourne avalia a viabilidade da migração, define a estratégia e identifica gaps e incompatibilidades entre o n8n e o sistema-alvo.

## Inputs

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `analysisReport` | string | Output do hannibal-dissect-workflow |
| `nodesMap` | object | Output do hannibal-map-nodes |
| `triggers` | object | Output do hannibal-identify-triggers |
| `targetSystem` | string | Sistema-alvo (make, zapier, nodejs, etc.) |

## Elicitação

```
? Há janela de downtime disponível para a migração?
  > sim — qual janela? ___
    não — migração deve ser transparente

? O sistema-alvo já está em uso ou é uma instalação nova?
  > novo (sem dados históricos)
    existente (cuidado com dados em voo)

? Qual é o SLA esperado para a automação migrada?
  > crítica (99.9% uptime)
    normal (99% uptime)
    best-effort
```

## Execução

1. Para cada node identificado por Hannibal:
   - Verificar se existe equivalente direto no sistema-alvo
   - Classificar: EQUIVALENT | ADAPT | WORKAROUND | INCOMPATIBLE
2. Calcular score de compatibilidade (% de nodes com equivalente direto)
3. Identificar nodes que precisam de workaround
4. Documentar nodes sem equivalente (requerem código customizado)
5. Definir estratégia de migração:
   - **Big Bang:** Tudo migrado de uma vez, downtime aceitável
   - **Incremental:** Migrar por grupos de nodes, paralelo
   - **Parallel Run:** Rodar ambos por período, validar saídas
6. Gerar plano de rollback

## Compatibilidade por Sistema-Alvo

| n8n Node | Make | Zapier | Node.js | Status |
|----------|------|--------|---------|--------|
| HTTP Request | HTTP Module | Webhooks | axios | EQUIVALENT |
| Code | JS Module | Code by Zapier | native | EQUIVALENT |
| IF | Router | Filter | if/else | EQUIVALENT |
| Merge | Aggregator | — | Promise.all | ADAPT |
| Execute Workflow | Scenario chain | — | function | WORKAROUND |

## Output

Arquivo: `migration-assessment.md`

```yaml
score: 87  # % de nodes com equivalente direto
strategy: incremental
downtime: none
risks:
  - node: "Execute Workflow"
    issue: "Sem equivalente direto no Make"
    workaround: "Usar webhooks para chamar outro cenário"
rollback:
  window: 48h
  procedure: "Reativar workflows n8n originais, redirecionar webhooks"
```
