---
task: Setup Credentials
agent: villanelle
elicit: true
---

# villanelle-setup-credentials

Villanelle configura todas as credenciais e autenticações necessárias para o sistema-alvo, garantindo acesso seguro a todas as APIs e serviços.

## Inputs

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `credentialsList` | array | Lista de credenciais identificadas por Hannibal |
| `targetSystem` | string | Sistema-alvo |

## Elicitação

Para cada credencial identificada:

```
? Credencial: {nome}
? Tipo de autenticação:
  > OAuth2
    API Key
    Bearer Token
    Basic Auth
    Custom Header

? [Se OAuth2]
  Client ID: ___
  Client Secret: ___
  Redirect URI: ___
  Scopes: ___

? [Se API Key]
  API Key: ___
  Posição: Header | Query Param
  Nome do campo: ___

? Ambiente: dev | staging | prod
```

## Execução

### OAuth2

```json
{
  "type": "oAuth2",
  "name": "HubSpot - Production",
  "clientId": "{{env.HUBSPOT_CLIENT_ID}}",
  "clientSecret": "{{env.HUBSPOT_CLIENT_SECRET}}",
  "accessTokenUrl": "https://api.hubapi.com/oauth/v1/token",
  "authUrl": "https://app.hubspot.com/oauth/authorize",
  "scope": "contacts crm.objects.contacts.read crm.objects.contacts.write"
}
```

### API Key

```json
{
  "type": "apiKey",
  "name": "Stripe - Production",
  "key": "{{env.STRIPE_SECRET_KEY}}",
  "placement": "header",
  "headerName": "Authorization",
  "prefix": "Bearer "
}
```

### Verificação Pós-Setup

1. Testar autenticação com request simples (GET /me ou equivalente)
2. Confirmar que scopes necessários estão autorizados
3. Confirmar TTL do token e configurar refresh se necessário
4. Documentar data de expiração se for chave estática

## Output

```yaml
credentials:
  - name: "HubSpot Production"
    type: oauth2
    status: CONFIGURED
    tested: true
    testResult: SUCCESS
    expiresAt: null  # OAuth2 com refresh automático
  - name: "Stripe Production"
    type: apiKey
    status: CONFIGURED
    tested: true
    testResult: SUCCESS
    expiresAt: "2027-01-01"  # Rotação anual recomendada
```
