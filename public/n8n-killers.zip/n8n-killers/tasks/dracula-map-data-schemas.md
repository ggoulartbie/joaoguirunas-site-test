---
task: Map Data Schemas
agent: dracula
elicit: false
---

# dracula-map-data-schemas

Drácula mapeia os schemas de dados entre o sistema-fonte (n8n) e o sistema-alvo, criando o contrato de transformação que guiará toda a implementação.

## Inputs

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `nodesMap` | object | Mapeamento de nodes (Hannibal) |
| `nodeEquivalents` | object | Mapeamento de equivalentes (Bourne) |

## Execução

Para cada ponto de transformação identificado:

1. Documentar schema de entrada (fonte)
2. Documentar schema de saída esperado (alvo)
3. Definir regras de transformação para cada campo
4. Identificar campos calculados ou derivados
5. Documentar campos opcionais e valores default

## Formato do Schema Map

```yaml
transformations:
  - name: "Customer Webhook to CRM Format"
    source:
      system: n8n-webhook
      schema:
        customer_id: string (required)
        customer_name: string (required)
        email_address: string (optional)
        signup_date: string (ISO8601)
        plan_type: string (enum: free|pro|enterprise)
    target:
      system: make-crm-module
      schema:
        id: string (required)
        name: string (required)
        email: string (optional, default: "")
        createdAt: timestamp (required)
        tier: string (enum: FREE|PRO|ENTERPRISE)
    rules:
      - field: id
        from: customer_id
        transform: passthrough
      - field: name
        from: customer_name
        transform: passthrough
      - field: email
        from: email_address
        transform: "if null then empty string"
      - field: createdAt
        from: signup_date
        transform: "parse ISO8601 → Unix timestamp"
      - field: tier
        from: plan_type
        transform: "uppercase()"
    calculatedFields:
      - field: updatedAt
        value: "current timestamp"
      - field: source
        value: "\"migrated-from-n8n\""
```

## Output

Arquivo: `data-schema-map.yaml`
