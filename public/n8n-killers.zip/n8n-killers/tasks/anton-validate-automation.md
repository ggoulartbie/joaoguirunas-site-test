---
task: Validate Automation
agent: anton
elicit: false
---

# anton-validate-automation

Anton executa a validação completa da automação — testes E2E, edge cases, performance e segurança. Emite o verdict final.

## Checklist de Validação

### Funcionalidade (obrigatório — todos devem passar)
- [ ] Happy path executa sem erros
- [ ] Todos os campos mapeados chegam corretamente ao destino
- [ ] Transformações de dados produzem output correto
- [ ] Sub-workflows executam e retornam dados esperados

### Error Handling (obrigatório)
- [ ] Falha de API: retry ativa, alerta enviado
- [ ] Credencial inválida: erro claro, não dados corrompidos
- [ ] Payload inválido: rejeitado com erro descritivo
- [ ] Rate limit: throttling respeita o limite
- [ ] Timeout: circuit breaker ativa quando configurado

### Segurança (obrigatório)
- [ ] HMAC signature: payload inválido rejeitado com 401
- [ ] Campos sensíveis não expostos em logs
- [ ] Credenciais não hardcoded em nenhum node

### Performance (referência)
- [ ] Execução simples: < 5 segundos
- [ ] Batch de 100 itens: < 60 segundos
- [ ] Sem memory leaks em loops longos

### Idempotência (quando aplicável)
- [ ] Evento duplicado: processado apenas uma vez
- [ ] Reprocessamento: sem duplicação de dados no destino

## Cenários de Teste

```yaml
testScenarios:
  - id: T001
    name: Happy path completo
    input: { valid payload }
    expectedOutput: { transformed data in target system }
    result: PASS | FAIL

  - id: T002
    name: API target down
    setup: mock API returning 503
    expectedBehavior: retry 3x, then alert Slack
    result: PASS | FAIL

  - id: T003
    name: Credencial expirada
    setup: invalidate credentials
    expectedBehavior: error 401, clear error message
    result: PASS | FAIL

  - id: T004
    name: Payload duplicado (idempotência)
    setup: send same event_id twice
    expectedBehavior: second execution ignored
    result: PASS | FAIL

  - id: T005
    name: Dados com campos opcionais ausentes
    input: { payload without optional fields }
    expectedBehavior: default values applied, no crash
    result: PASS | FAIL
```

## Formato do Verdict

```yaml
verdict: PASS | FAIL
operationId: "OP-20260414-001"
timestamp: "2026-04-14T16:00:00Z"
tests:
  total: 12
  passed: 12
  failed: 0
issues: []
performance:
  avgExecution: "2.1s"
  maxExecution: "4.8s"
  errorRate: "0%"
signature: "Anton Chigurh — QA Validator"
recommendation: "Aprovado para produção. Monitorar nas primeiras 48h."
```

**IMPORTANTE:** Verdict FAIL bloqueia a operação. A operação não fecha até PASS.
