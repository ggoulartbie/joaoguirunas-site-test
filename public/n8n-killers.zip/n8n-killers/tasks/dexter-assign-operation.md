---
task: Assign Operation
agent: dexter
elicit: true
---

# dexter-assign-operation

Dexter lê o briefing da operação, avalia o tipo e a complexidade, e distribui o trabalho para os agentes corretos com contexto completo.

## Inputs

| Campo | Tipo | Obrigatório | Descrição |
|-------|------|-------------|-----------|
| `type` | enum | sim | `migration` ou `new-automation` |
| `description` | string | sim | Descrição da operação |
| `source` | string | condicional | Path do workflow n8n (para migration) |
| `target` | string | sim | Sistema-alvo (make, zapier, nodejs, api) |
| `priority` | enum | não | `high`, `normal`, `low` (default: normal) |

## Elicitação

```
? Tipo da operação:
  > migration (migrar workflow n8n existente)
    new-automation (criar automação nova do zero)

? Descrição da operação: ___

? Sistema-alvo:
  > make
    zapier
    pipedream
    nodejs
    api-rest-generica

? [Se migration] Path do workflow n8n (.json): ___

? Prioridade:
  > normal
    high
    low
```

## Execução

1. Gerar ID da operação: `OP-{timestamp}`
2. Avaliar tipo e complexidade
3. Selecionar sequência de agentes
4. Para cada agente, gerar briefing específico com:
   - O que ele precisa fazer
   - Inputs disponíveis
   - Output esperado
   - Agente que recebe o output
5. Registrar operação em `.aiox/n8n-killers/ops/OP-{id}.yaml`
6. Exibir plano de execução

## Output

```yaml
operationId: "OP-20260414-001"
type: migration | new-automation
target: make
status: assigned
sequence:
  - agent: hannibal
    task: hannibal-dissect-workflow
    status: pending
  - agent: bourne
    task: bourne-assess-migration
    status: pending
  # ...
```
