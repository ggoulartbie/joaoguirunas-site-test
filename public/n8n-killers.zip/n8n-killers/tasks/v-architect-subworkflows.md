---
task: Architect Sub-workflows
agent: v
elicit: true
---

# v-architect-subworkflows

V projeta sub-workflows reutilizáveis que encapsulam lógica comum e podem ser chamados por múltiplos workflows principais.

## Quando Criar Sub-workflows

- Mesma lógica usada em 2+ workflows
- Operação complexa que merece isolamento (ex: enriquecimento de dados)
- Error handling específico que deve ser consistente
- Lógica que pode evoluir independentemente

## Elicitação

```
? Que lógica será encapsulada no sub-workflow? ___
? Quantos workflows diferentes vão chamá-lo? ___
? Deve executar sync (aguardar resultado) ou async?
  > sync (retorna dados ao caller)
    async (fire-and-forget)
? Precisa de inputs? (Y/n)
  ? Quais campos: ___
? Quais dados retorna? ___
```

## Padrão de Sub-workflow

### 1. Definição do Contrato

```yaml
subWorkflow:
  name: "Enrich Contact"
  description: "Enriquece dados de contato com informações de empresa via Clearbit"

  inputs:
    type: object
    required: [email]
    properties:
      email:
        type: string
        format: email
      name:
        type: string

  outputs:
    type: object
    properties:
      company:
        type: object
        properties:
          name: string
          domain: string
          size: string
          industry: string
      enriched:
        type: boolean
      error:
        type: string  # Presente apenas se falhou
```

### 2. Estrutura Interna

```
[Execute Workflow Trigger]  ← recebe inputs do caller
    ↓
[Validate Inputs]           ← garante que email é válido
    ↓
[Fetch from Clearbit]       ← HTTP Request → continueOnFail=true
    ↓
[Handle Not Found]          ← IF: Clearbit retornou dados?
    ↓ YES                       ↓ NO
[Transform Data]           [Return empty enrichment]
    ↓
[Return Enriched Data]      ← output para o caller
```

### 3. Chamar o Sub-workflow

```json
{
  "type": "n8n-nodes-base.executeWorkflow",
  "parameters": {
    "workflowId": "{{ $env.SUBWORKFLOW_ENRICH_CONTACT_ID }}",
    "waitForSubWorkflow": true,
    "source": "database",
    "mode": "each",
    "workflowInputs": {
      "values": [
        { "name": "email", "value": "={{ $json.email }}" },
        { "name": "name", "value": "={{ $json.name }}" }
      ]
    }
  }
}
```

## Catálogo de Sub-workflows Recomendados

| Sub-workflow | Propósito | Inputs | Outputs |
|-------------|-----------|--------|---------|
| `enrich-contact` | Enriquece com Clearbit | email | company data |
| `send-slack-alert` | Alerta padronizado | message, severity | sent: bool |
| `validate-email` | Valida formato e domínio | email | valid: bool |
| `rate-limit-guard` | Verifica rate limit antes de chamar API | api_name | can_proceed: bool |
| `log-operation` | Registra operação em DB | event, data | logged: bool |

## Output

- Sub-workflows criados e ativados
- Contrato (inputs/outputs) documentado
- IDs dos sub-workflows documentados para referência
