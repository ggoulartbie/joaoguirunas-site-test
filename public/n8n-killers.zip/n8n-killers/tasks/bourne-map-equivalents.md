---
task: Map Node Equivalents
agent: bourne
elicit: false
---

# bourne-map-equivalents

Bourne mapeia cada node do workflow n8n para seu equivalente no sistema-alvo, gerando o dicionário de tradução que guiará a implementação por Lisbeth.

## Inputs

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `nodesMap` | object | Mapeamento detalhado de nodes (Hannibal) |
| `targetSystem` | string | Sistema-alvo |
| `migrationAssessment` | object | Assessment de Bourne |

## Execução

Para cada node do workflow original:

1. Identificar tipo e comportamento
2. Localizar equivalente no sistema-alvo
3. Documentar diferenças de comportamento
4. Definir configuração no sistema-alvo
5. Listar dados necessários para recriar (parâmetros, auth, etc.)

## Formato do Mapeamento

```yaml
mappings:
  - sourceNode:
      id: "uuid-001"
      name: "Get Customer"
      type: "n8n-nodes-base.httpRequest"
      config:
        method: GET
        url: "https://api.crm.com/customers/{{ $json.id }}"
    targetNode:
      system: make
      module: "HTTP > Make a request"
      config:
        method: GET
        url: "https://api.crm.com/customers/{{1.id}}"
        headers:
          - name: Authorization
            value: "Bearer {{connection.crm_api_key}}"
    differences:
      - "Expressão n8n `{{ $json.id }}` → Make `{{1.id}}`"
      - "Auth gerenciada por Connection no Make vs node config no n8n"
    migrationComplexity: LOW | MEDIUM | HIGH | MANUAL

  - sourceNode:
      name: "Execute Sub-Workflow"
      type: "n8n-nodes-base.executeWorkflow"
    targetNode:
      system: make
      module: "WORKAROUND: HTTP call para webhook do cenário filho"
    differences:
      - "Make não tem chaining nativo — usar webhook intermediário"
    migrationComplexity: HIGH
```

## Output

Arquivo: `node-equivalents-map.yaml`
