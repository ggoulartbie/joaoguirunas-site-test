---
task: Setup Monitoring
agent: amy
elicit: true
---

# amy-setup-monitoring

Amy configura monitoramento contínuo das automações, com alertas proativos e dashboards de status.

## Elicitação

```
? Ferramentas de monitoramento disponíveis?
  [x] Slack
  [ ] Grafana
  [ ] Datadog
  [ ] Custom webhook
  [ ] Apenas logs do n8n

? Qual é a SLA esperada?
  > 99.9% (crítico)
    99% (normal)
    best-effort

? Alertar quando:
  [x] Workflow falha
  [x] Taxa de erro > 5%
  [x] Tempo de execução > threshold
  [ ] Execução não acontece no horário esperado (heartbeat)
```

## Métricas Monitoradas

| Métrica | Threshold | Ação |
|---------|-----------|------|
| Taxa de erro | > 5% em 1h | Alert Slack |
| Tempo de execução | > 30s (simples) / > 5min (batch) | Warning |
| Execuções falhas consecutivas | > 3 | Alert + PagerDuty |
| Heartbeat ausente | Schedule não executou | Alert |
| Rate limit atingido | X-RateLimit-Remaining < 10% | Warning |

## Workflow de Monitoramento (Heartbeat)

```yaml
# Workflow que verifica se a automação principal está ativa
name: "Heartbeat Monitor — Customer Sync"
trigger:
  type: schedule
  cron: "*/15 * * * *"  # A cada 15 minutos

steps:
  1. GET /api/v1/workflows/{id} → verificar active: true
  2. GET /api/v1/executions?workflowId={id}&limit=1 → verificar última execução
  3. Se última execução > threshold → alertar
  4. Se workflow inactive → alertar imediatamente
```

## Dashboard de Status (Slack)

```
📊 *n8n Killers — Daily Status Report*
Date: {{ $now.toFormat('dd/MM/yyyy') }}

✅ Customer Sync: 247 execuções, 0 falhas (100%)
✅ Lead Enrichment: 89 execuções, 2 falhas (97.8%)
⚠️  Invoice Generator: 12 execuções, 1 falha (91.7%) — abaixo do SLA

Total: 348 execuções | 3 falhas | 99.1% success rate
```

## Output

- Heartbeat workflow configurado
- Daily report automatizado
- Alertas em tempo real ativos
- Documentação dos thresholds e procedimentos
