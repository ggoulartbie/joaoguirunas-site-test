---
task: Dissect n8n Workflow
agent: hannibal
elicit: true
---

# hannibal-dissect-workflow

Hannibal lê e disseca o JSON de um workflow n8n, gerando um relatório estruturado completo com todos os nodes, conexões, triggers e metadados.

## Inputs

| Campo | Tipo | Obrigatório | Descrição |
|-------|------|-------------|-----------|
| `file` | string | sim | Path para o arquivo .json do workflow n8n |
| `verbose` | boolean | não | Incluir configuração raw de cada node (default: false) |

## Elicitação

```
? Path do arquivo n8n JSON: ___
? Incluir configuração detalhada de cada node? (y/N)
```

## Execução

1. Ler e parsear o JSON do workflow n8n
2. Extrair metadados do workflow:
   - `id`, `name`, `active`, `createdAt`, `updatedAt`
3. Inventariar todos os nodes:
   - Tipo (`nodeType`), nome, posição no canvas
   - Configuração de parâmetros
   - Credencial referenciada (se houver)
4. Mapear todas as conexões (`connections`) entre nodes
5. Identificar nodes de entrada (sem conexões de entrada)
6. Identificar nodes de saída (sem conexões de saída)
7. Identificar expressões JavaScript em parâmetros
8. Detectar sub-workflows referenciados (Execute Workflow nodes)
9. Listar todas as credenciais necessárias
10. Gerar relatório usando `workflow-analysis-report-tmpl.md`

## Output

Arquivo: `workflow-analysis-report.md`

### Estrutura do Relatório

```markdown
# Workflow Analysis Report

## Metadados
- Nome: ...
- ID: ...
- Nodes: N
- Triggers: N
- Credenciais: N

## Inventory de Nodes
| # | Nome | Tipo | Credencial | Notas |
|---|------|------|-----------|-------|

## Grafo de Conexões
[Representação do fluxo]

## Triggers Identificados
[Lista com tipo, path/schedule]

## Credenciais Necessárias
[Lista]

## Expressões Complexas
[Lista de expressões não triviais]

## Riscos & Pontos de Atenção
[Issues para migração]
```
