---
task: Create Incident Playbook
agent: amy
elicit: false
---

# amy-incident-playbook

Amy cria o playbook de resposta a incidentes para a automação, com procedimentos claros para cada tipo de falha.

## Template de Playbook

```markdown
# Incident Playbook — {Automation Name}

## Classificação de Incidentes

| Severidade | Critério | SLA de Resposta |
|-----------|---------|----------------|
| P1 — Crítico | Automação core parada, impacto direto no negócio | 15 min |
| P2 — Alto | Degradação significativa, erros > 20% | 1 hora |
| P3 — Médio | Erros intermitentes, degradação parcial | 4 horas |
| P4 — Baixo | Alertas de monitoring, sem impacto imediato | Próximo dia útil |

---

## Runbook: Workflow Parado (P1)

**Sintoma:** Workflow `active: false` ou sem execuções nas últimas X horas

**Diagnóstico:**
1. Acessar n8n: Settings > Executions → verificar última execução
2. Verificar logs de erro: qual node falhou?
3. Verificar status da API externa: `curl -I https://api.target.com/health`

**Resolução:**
1. Se erro de credencial: @villanelle *rotate-credentials
2. Se API externa down: aguardar recovery, não tomar ação
3. Se bug no workflow: @lisbeth corrigir + @anton validar
4. Reativar workflow: PATCH /api/v1/workflows/{id} { "active": true }

---

## Runbook: Rate Limit Atingido (P2)

**Sintoma:** Erros 429 em sequência nos logs

**Diagnóstico:**
1. Verificar header `X-RateLimit-Reset` para saber quando reset
2. Verificar volume atual vs limite documentado

**Resolução:**
1. Pausar workflow até reset do rate limit
2. Implementar throttling mais agressivo via Amy
3. Se frequente: negociar limite maior com provider da API

---

## Runbook: Credencial Expirada (P2)

**Sintoma:** Erros 401 ou 403 em requests autenticados

**Resolução:**
1. @villanelle *rotate-credentials {credential-name}
2. Reativar workflow após nova credencial configurada
3. Documentar nova data de expiração

---

## Runbook: Dados Corrompidos (P1)

**Sintoma:** Dados incorretos chegando ao sistema-alvo

**Resolução:**
1. Pausar workflow IMEDIATAMENTE
2. Identificar janela de dados corrompidos (timestamp início)
3. @dracula analisar transformação que produziu dados errados
4. @bourne avaliar rollback dos dados no sistema-alvo
5. Corrigir transformação + @anton validar
6. Reprocessar dados da janela afetada

---

## Contatos

| Role | Responsável | Canal |
|------|------------|-------|
| Automação | @n8n-killers squad | #automation-alerts |
| Infra n8n | @devops | #devops |
| Escalação negócio | Product Owner | DM direto |
```

## Output

Arquivo: `incident-playbook-{automation}.md`
