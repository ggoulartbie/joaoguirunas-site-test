---
task: Build Custom n8n Node
agent: lisbeth
elicit: true
---

# lisbeth-build-custom-node

Lisbeth desenvolve custom nodes em TypeScript para o n8n quando nenhum node existente atende ao requisito da automação.

## Quando Usar

- API específica sem node n8n oficial
- Lógica de negócio muito específica para o HTTP Request node
- Performance: node nativo é mais rápido que Code node para operações repetidas
- Reutilização: mesmo node usado em múltiplos workflows

## Elicitação

```
? Nome do node (PascalCase): ___
? Descrição: ___
? Tipo:
  > Regular node (executa uma ação)
    Trigger node (inicia workflow)
    Credential-only (só define auth)
? Quantas operações o node terá? ___
```

## Estrutura do Custom Node

```typescript
// src/nodes/MyCustomNode/MyCustomNode.node.ts
import {
  IExecuteFunctions,
  INodeExecutionData,
  INodeType,
  INodeTypeDescription,
  NodeOperationError,
} from 'n8n-workflow';

export class MyCustomNode implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'My Custom Node',
    name: 'myCustomNode',
    icon: 'fa:bolt',
    group: ['transform'],
    version: 1,
    description: 'Integração customizada com Sistema X',
    defaults: {
      name: 'My Custom Node',
    },
    inputs: ['main'],
    outputs: ['main'],
    credentials: [
      {
        name: 'myCustomApi',
        required: true,
      },
    ],
    properties: [
      {
        displayName: 'Operation',
        name: 'operation',
        type: 'options',
        noDataExpression: true,
        options: [
          { name: 'Get', value: 'get' },
          { name: 'Create', value: 'create' },
          { name: 'Update', value: 'update' },
          { name: 'Delete', value: 'delete' },
        ],
        default: 'get',
      },
      {
        displayName: 'Resource ID',
        name: 'resourceId',
        type: 'string',
        displayOptions: {
          show: { operation: ['get', 'update', 'delete'] },
        },
        default: '',
        required: true,
        description: 'ID do recurso',
      },
    ],
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const returnData: INodeExecutionData[] = [];

    for (let i = 0; i < items.length; i++) {
      const operation = this.getNodeParameter('operation', i) as string;
      const credentials = await this.getCredentials('myCustomApi');

      try {
        let result;
        if (operation === 'get') {
          const resourceId = this.getNodeParameter('resourceId', i) as string;
          result = await this.helpers.httpRequest({
            method: 'GET',
            url: `${credentials.baseUrl}/resources/${resourceId}`,
            headers: { Authorization: `Bearer ${credentials.apiKey}` },
          });
        }
        returnData.push({ json: result });
      } catch (error) {
        if (this.continueOnFail()) {
          returnData.push({ json: { error: error.message } });
          continue;
        }
        throw new NodeOperationError(this.getNode(), error, { itemIndex: i });
      }
    }

    return [returnData];
  }
}
```

## Output

- Custom node TypeScript compilado
- Credential type definido
- Testes unitários básicos
- Instruções de instalação no n8n
