---
task: Finalize Operation
agent: dexter
elicit: false
---

# dexter-finalize-operation

Dexter consolida todos os outputs dos agentes, valida que a operação está completa e gera o handoff final documentado.

## Inputs

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `operationId` | string | ID da operação (ex: OP-20260414-001) |
| `antonVerdict` | enum | `PASS` ou `FAIL` — obrigatório para fechar |

## Pré-condições

- Anton deve ter emitido verdict `PASS`
- Todos os agentes da sequência devem ter entregado seus outputs
- Nenhum blocker ativo

## Execução

1. Verificar verdict de Anton — se `FAIL`, **bloquear e escalar**
2. Coletar outputs de todos os agentes da operação
3. Consolidar no template `operation-handoff-tmpl.md`
4. Registrar status final no arquivo da operação
5. Exibir resumo da operação ao usuário

## Output

Arquivo: `.aiox/n8n-killers/ops/OP-{id}-handoff.md`

```markdown
# Operation Handoff — OP-{id}

## Resultado: ✅ CONCLUÍDO

- Tipo: migration / new-automation
- Sistema-alvo: make
- Duração: ~2h
- Verdict QA: PASS

## O que foi feito
- [x] Workflow n8n analisado por Hannibal
- [x] Estratégia definida por Bourne
- [x] Dados mapeados por Drácula
- [x] Credenciais configuradas por Villanelle
- [x] Triggers migrados por Ghostface
- [x] Implementação por Lisbeth
- [x] Error handling por Amy
- [x] Validação por Anton

## Arquivos gerados
- workflow-analysis-report.md
- migration-assessment.md
- automation-spec.md

## Próximos passos
- Deploy em produção via @devops
```
