---
task: Map n8n Nodes
agent: hannibal
elicit: false
---

# hannibal-map-nodes

Hannibal realiza o mapeamento detalhado de cada node do workflow, documentando entradas, saídas, transformações e dependências.

## Inputs

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `workflowJson` | object | JSON do workflow já parseado |
| `analysisReport` | string | Output do hannibal-dissect-workflow |

## Execução

Para cada node identificado:

1. **Documentar tipo e subtype**
   - Core node, App node, Trigger node, Utility node
2. **Mapear dados de entrada esperados**
   - Schema do `$json` que o node recebe
   - Campos obrigatórios vs opcionais
3. **Mapear dados de saída produzidos**
   - Schema do `$json` que o node emite
   - Transformações aplicadas
4. **Documentar configuração operacional**
   - Parâmetros configurados
   - Expressões usadas
   - Modo de execução (once, forEachItem)
5. **Identificar dependências**
   - Nodes que precisam executar antes
   - Credenciais necessárias
   - Variáveis de ambiente referenciadas
6. **Classificar criticidade**
   - CRITICAL: falha bloqueia o fluxo todo
   - HIGH: falha impacta funcionalidade principal
   - LOW: falha é contornável

## Output

```yaml
nodes:
  - id: "node-uuid"
    name: "Get Customer Data"
    type: "n8n-nodes-base.httpRequest"
    criticality: CRITICAL
    inputs:
      from: ["Webhook Trigger"]
      schema:
        customerId: string
    outputs:
      schema:
        customer:
          id: string
          name: string
          email: string
    config:
      method: GET
      url: "https://api.crm.com/customers/{{ $json.customerId }}"
      auth: "CRM API Key"
    dependencies:
      nodes: ["Webhook Trigger"]
      credentials: ["CRM API Key"]
```
