---
task: Environment Configuration
agent: villanelle
elicit: true
---

# villanelle-env-config

Villanelle configura as variáveis de ambiente necessárias para a automação, garantindo isolamento entre ambientes e proteção de dados sensíveis.

## Elicitação

```
? Quais ambientes existem?
  [x] development
  [ ] staging
  [x] production

? Onde as env vars serão armazenadas?
  > .env file (local dev)
    Docker secrets
    GitHub Actions secrets
    Sistema de secrets do cloud provider
    Vault / AWS Secrets Manager
```

## Template de .env

```bash
# n8n-killers — Environment Variables
# NUNCA commitar este arquivo com valores reais

# === n8n Configuration ===
N8N_ENCRYPTION_KEY=          # Chave de criptografia de credenciais
N8N_BASIC_AUTH_ACTIVE=true
N8N_BASIC_AUTH_USER=
N8N_BASIC_AUTH_PASSWORD=

# === Webhook Security ===
WEBHOOK_SECRET=              # Segredo para HMAC de webhooks

# === Integrations ===
# HubSpot
HUBSPOT_CLIENT_ID=
HUBSPOT_CLIENT_SECRET=
HUBSPOT_ACCESS_TOKEN=        # Preencher após OAuth flow

# Stripe
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=

# Slack
SLACK_BOT_TOKEN=
SLACK_SIGNING_SECRET=

# === Monitoring ===
ALERT_SLACK_WEBHOOK=         # Webhook para alertas de erro
PAGERDUTY_ROUTING_KEY=       # Opcional: para incidentes críticos

# === Database (se necessário) ===
DB_URL=
DB_NAME=
```

## Regras de Isolamento

| Variável | Dev | Staging | Prod |
|----------|-----|---------|------|
| APIs externas | Sandbox/Test | Staging | Production |
| Webhook URLs | localhost/ngrok | staging.domain | api.domain |
| Database | Local/test DB | Staging DB | Prod DB |
| Alertas | Slack #dev-alerts | Slack #staging | Slack #prod-alerts |

## Output

- `.env.example` (template sem valores, para commitar)
- Documentação de onde obter cada valor
- Checklist de variáveis configuradas por ambiente
