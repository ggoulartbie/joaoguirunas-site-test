---
task: Discover API
agent: lisbeth
elicit: true
---

# lisbeth-discover-api

Lisbeth explora e documenta a API do sistema-alvo, mapeando endpoints, autenticação, formatos de dados e limitações técnicas.

## Elicitação

```
? URL base da API: ___
? Documentação disponível? (Y/n)
  ? URL da documentação: ___
? Tipo de autenticação:
  > API Key
    OAuth2
    Bearer Token
    Basic Auth
? A API tem rate limit documentado? (Y/n)
  ? Limite: ___ req / ___ seg
? A API suporta paginação? (Y/n)
```

## Execução

### 1. Descoberta de Endpoints

Para cada funcionalidade necessária, identificar:

```yaml
endpoints:
  - method: GET
    path: /v1/customers/{id}
    description: Buscar cliente por ID
    auth: bearer
    rateLimit: 100/min
    request:
      params:
        id: string (required)
    response:
      200:
        schema:
          id: string
          name: string
          email: string
      404:
        description: Cliente não encontrado
      401:
        description: Token inválido ou expirado
```

### 2. Teste de Autenticação

```bash
# Teste básico de autenticação
curl -X GET https://api.target.com/v1/me \
  -H "Authorization: Bearer {token}"

# Resposta esperada: 200 com dados do usuário autenticado
```

### 3. Mapeamento de Rate Limits

```yaml
rateLimits:
  global: 1000 req/min
  perEndpoint:
    POST /contacts: 100 req/min
    GET /contacts: 500 req/min
  headers:
    remaining: X-RateLimit-Remaining
    reset: X-RateLimit-Reset
```

### 4. Paginação

```yaml
pagination:
  type: cursor | page | offset
  params:
    cursor: next_cursor (in response body)
    page: ?page=N&per_page=100
    offset: ?offset=N&limit=100
  maxPageSize: 100
```

## Output

Arquivo: `api-discovery-{target}.md`

Contém:
- Lista completa de endpoints usados
- Autenticação documentada e testada
- Rate limits mapeados
- Paginação documentada
- Exemplos de request/response reais
