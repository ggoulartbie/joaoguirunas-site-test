---
task: Migrate Triggers
agent: ghostface
elicit: false
---

# ghostface-migrate-triggers

Ghostface migra os triggers do workflow n8n original para o sistema-alvo, garantindo equivalência funcional e atualizando configurações nos sistemas-fonte.

## Inputs

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `triggersDoc` | object | Output do hannibal-identify-triggers |
| `targetSystem` | string | Sistema-alvo |
| `credentials` | object | Credenciais configuradas por Villanelle |

## Execução por Tipo de Trigger

### Webhook → Webhook

1. Criar novo endpoint de webhook no sistema-alvo
2. Copiar URL gerada
3. Atualizar URL no sistema-fonte (GitHub, HubSpot, Stripe, etc.)
4. Configurar autenticação equivalente
5. Testar com evento de teste do sistema-fonte

```yaml
migration:
  original:
    system: n8n
    url: "https://n8n.company.com/webhook/abc123"
  migrated:
    system: make
    url: "https://hook.make.com/xyz789"
  action: "Atualizar webhook URL no HubSpot: Settings > Integrations > Webhooks"
```

### Schedule → Schedule

```yaml
original:
  cronExpression: "0 9 * * 1-5"
  timezone: "America/Sao_Paulo"
migrated:
  system: make
  config:
    type: "scheduled"
    interval: "custom"
    cron: "0 9 * * 1-5"
    timezone: "America/Sao_Paulo"
```

### Email Trigger → Email Trigger (se suportado)

```yaml
original:
  protocol: imap
  server: imap.gmail.com
  mailbox: INBOX
  filter: "from:alerts@system.com"
migrated:
  system: make
  module: "Gmail > Watch emails"
  config:
    label: INBOX
    sender: "alerts@system.com"
    markAsRead: true
```

## Plano de Cutover

1. Criar trigger no sistema-alvo (ainda desativado)
2. Validar configuração sem ativar
3. Desativar trigger original no n8n
4. Ativar trigger no sistema-alvo
5. Confirmar primeiro evento processado com sucesso
6. Documentar timestamp do cutover

## Output

```yaml
triggersMigrated:
  - name: "Customer Webhook"
    status: MIGRATED
    cutovertAt: "2026-04-14T14:00:00Z"
    verified: true
  - name: "Daily Report Schedule"
    status: MIGRATED
    cutovertAt: "2026-04-14T14:05:00Z"
    verified: true
```
