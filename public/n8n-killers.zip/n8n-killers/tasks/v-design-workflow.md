---
task: Design Workflow
agent: v
elicit: true
---

# v-design-workflow

V projeta o workflow completo antes de qualquer implementação, definindo arquitetura, fluxo de dados, nodes necessários e padrões de composição.

## Elicitação

```
? Descrição da automação em uma frase: ___

? Qual é o trigger?
  > Webhook (evento externo)
    Schedule (periódico)
    Manual (sob demanda)
    Outro: ___

? Quais sistemas externos estão envolvidos?
  → Lista de sistemas

? Qual o volume esperado?
  > < 100 itens/execução (simples)
    100-1000 itens (médio)
    > 1000 itens (batch/ETL)

? Há necessidade de sub-workflows reutilizáveis? (Y/n)

? SLA esperado?
  > Crítico (99.9%)
    Normal (99%)
    Best-effort
```

## Execução

### 1. Definir Padrão Arquitetural

```
Trigger-Process-Action (padrão básico):
[TRIGGER] → [VALIDATE] → [FETCH DATA] → [TRANSFORM] → [ACTION] → [NOTIFY]

Fan-out (múltiplos destinos):
[TRIGGER] → [FETCH] → [TRANSFORM] → [ACTION A]
                                   → [ACTION B]
                                   → [ACTION C]

Fan-in (múltiplas fontes):
[TRIGGER] → [FETCH A] → [MERGE] → [TRANSFORM] → [ACTION]
           → [FETCH B] →

ETL (alto volume):
[TRIGGER] → [PAGINATE] → [TRANSFORM BATCH] → [WRITE BATCH] → [REPORT]
```

### 2. Spec do Workflow

```yaml
name: "Customer Sync — HubSpot to Notion"
pattern: trigger-process-action
trigger:
  type: webhook
  event: "contact.created"
  source: HubSpot

nodes:
  - name: "Receive HubSpot Webhook"
    type: webhook
    validates: [signature, payload-schema]

  - name: "Validate Contact Data"
    type: code
    validates: [required-fields, email-format]
    onFail: continueOnFail=false

  - name: "Enrich with Company Data"
    type: http-request
    target: Clearbit API
    critical: false  # continueOnFail=true

  - name: "Transform to Notion Format"
    type: set
    transforms: [field-mapping, date-conversion]

  - name: "Create Notion Page"
    type: notion
    operation: create-page
    critical: true

  - name: "Notify Slack on Success"
    type: slack
    critical: false

connections:
  - from: "Receive HubSpot Webhook"
    to: "Validate Contact Data"
  - from: "Validate Contact Data"
    to: "Enrich with Company Data"
  - from: "Enrich with Company Data"
    to: "Transform to Notion Format"
  - from: "Transform to Notion Format"
    to: "Create Notion Page"
  - from: "Create Notion Page"
    to: "Notify Slack on Success"

errorWorkflow: "n8n-killers Error Handler"
```

## Output

Arquivo: `automation-spec-{name}.md`
