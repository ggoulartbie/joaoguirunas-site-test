---
task: Implement HTTP Nodes
agent: lisbeth
elicit: false
---

# lisbeth-implement-http-nodes

Lisbeth implementa todos os nodes de integração HTTP da automação, configurando requests, headers, autenticação e tratamento de resposta.

## Inputs

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `apiDiscovery` | object | Output do lisbeth-discover-api |
| `nodeEquivalents` | object | Mapeamento de nodes (Bourne) |
| `transformations` | object | Transformações (Drácula) |
| `credentials` | object | Credenciais configuradas (Villanelle) |

## Padrões de Implementação

### GET Request

```json
{
  "method": "GET",
  "url": "=https://api.example.com/customers/{{ $json.customerId }}",
  "authentication": "genericCredentialType",
  "genericAuthType": "httpBearerAuth",
  "options": {
    "timeout": 10000,
    "response": {
      "response": {
        "neverError": false,
        "responseFormat": "json"
      }
    }
  }
}
```

### POST Request com Body

```json
{
  "method": "POST",
  "url": "https://api.example.com/contacts",
  "authentication": "genericCredentialType",
  "genericAuthType": "httpBearerAuth",
  "sendBody": true,
  "bodyParameters": {
    "parameters": [
      { "name": "name", "value": "={{ $json.name }}" },
      { "name": "email", "value": "={{ $json.email }}" },
      { "name": "source", "value": "n8n-killers-automation" }
    ]
  },
  "options": {
    "timeout": 15000
  }
}
```

### Request com Paginação

```javascript
// Code node — Fetch all pages
const baseUrl = 'https://api.example.com/contacts';
const headers = { Authorization: `Bearer ${$env.API_KEY}` };
let allContacts = [];
let page = 1;
let hasMore = true;

while (hasMore) {
  const response = await this.helpers.httpRequest({
    method: 'GET',
    url: `${baseUrl}?page=${page}&per_page=100`,
    headers
  });

  allContacts = allContacts.concat(response.data);
  hasMore = response.has_more;
  page++;

  if (page > 100) break; // Safety limit
}

return allContacts.map(contact => ({ json: contact }));
```

### Tratamento de Erros HTTP

```javascript
// Verificar código de resposta e tratar
const statusCode = $json.statusCode;

if (statusCode === 429) {
  // Rate limit — aguardar e tentar novamente
  const retryAfter = $json.headers['retry-after'] || 60;
  throw new Error(`Rate limited. Retry after ${retryAfter}s`);
}

if (statusCode >= 500) {
  // Erro do servidor — retry
  throw new Error(`Server error ${statusCode}: ${$json.body.message}`);
}

if (statusCode >= 400) {
  // Erro do cliente — não fazer retry
  console.error(`Client error ${statusCode}: ${$json.body.message}`);
  return []; // Ou throw dependendo da criticidade
}
```

## Output

- Todos os nodes HTTP configurados e testados
- Documentação de cada endpoint implementado
- Notas de edge cases encontrados
