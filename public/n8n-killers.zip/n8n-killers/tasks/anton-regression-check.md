---
task: Regression Check
agent: anton
elicit: false
---

# anton-regression-check

Anton verifica que mudanças na automação não quebraram funcionalidades existentes — executado após qualquer modificação pós-deploy.

## Quando Executar

- Após qualquer modificação em workflow em produção
- Após atualização de credenciais
- Após mudança de API externa (novo schema, nova versão)
- Após migração parcial (antes de desativar o n8n original)

## Execução

### 1. Baseline de Referência

Antes de qualquer mudança, Anton captura:
```yaml
baseline:
  date: "2026-04-14T12:00:00Z"
  sampleExecutions:
    - executionId: "exec-001"
      input: { ... }
      output: { ... }
      duration: 2.1s
  successRate: 100%
  avgDuration: 2.3s
```

### 2. Comparação Pós-Mudança

```yaml
comparison:
  baseline:
    successRate: 100%
    avgDuration: 2.3s
    outputSchema: { id, name, email, createdAt }
  current:
    successRate: 100%
    avgDuration: 2.4s  # +4% — ACCEPTABLE
    outputSchema: { id, name, email, createdAt }  # MATCH

  regressions:
    - field: duration
      change: +4%
      verdict: ACCEPTABLE (< 20%)
    - field: outputSchema
      change: none
      verdict: PASS
```

### 3. Checklist de Regressão

- [ ] Sucesso rate igual ou melhor que baseline
- [ ] Output schema não mudou para campos existentes
- [ ] Tempo de execução dentro de ±20% do baseline
- [ ] Error handling ainda funciona nos mesmos cenários
- [ ] Integrações externas ainda autenticam corretamente

## Output

```yaml
regressionCheck:
  status: CLEAR | REGRESSION_DETECTED
  timestamp: "2026-04-14T18:00:00Z"
  regressions: []
  recommendation: "Nenhuma regressão detectada. Mudança aprovada."
```

**REGRESSION_DETECTED bloqueia deploy** — @dexter escalona para análise.
