---
task: Implement Data Transformations
agent: dracula
elicit: false
---

# dracula-implement-transformations

Drácula implementa as transformações de dados definidas no schema map, usando expressões n8n, Code nodes ou equivalentes no sistema-alvo.

## Inputs

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `schemaMap` | object | Output do dracula-map-data-schemas |
| `targetSystem` | string | Sistema-alvo |

## Execução

Para cada transformação no schema map:

### 1. Expressões Simples (n8n / Make / Zapier)

```javascript
// Renomear campo
{{ $json.customer_id }}          // → id

// Transformar string
{{ $json.plan_type.toUpperCase() }}  // → FREE | PRO | ENTERPRISE

// Converter data
{{ DateTime.fromISO($json.signup_date).toUnixInteger() }}

// Valor default para null
{{ $json.email_address ?? "" }}

// Campo calculado
{{ $now.toISO() }}  // → current timestamp
```

### 2. Transformações Complexas (Code Node)

```javascript
// Para transformações que não cabem em expressões simples
const items = $input.all();

return items.map(item => {
  const source = item.json;

  return {
    json: {
      id: source.customer_id,
      name: source.customer_name,
      email: source.email_address || "",
      createdAt: Math.floor(new Date(source.signup_date).getTime() / 1000),
      tier: source.plan_type.toUpperCase(),
      updatedAt: Math.floor(Date.now() / 1000),
      source: "migrated-from-n8n"
    }
  };
});
```

### 3. Transformações Make (fórmulas)

```
// Renomear
{{1.customer_id}}

// Uppercase
{{toUpperCase(1.plan_type)}}

// Timestamp
{{formatDate(parseDate(1.signup_date; "YYYY-MM-DD"); "X")}}

// Default
{{if(isEmpty(1.email_address); ""; 1.email_address)}}
```

## Output

Arquivo: `transformations-implementation.md`

Contém:
- Código/expressões para cada transformação
- Anotações de onde aplicar no sistema-alvo
- Casos de borda e como tratá-los
