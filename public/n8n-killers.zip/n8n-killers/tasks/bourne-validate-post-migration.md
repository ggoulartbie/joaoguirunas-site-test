---
task: Validate Post Migration
agent: bourne
elicit: false
---

# bourne-validate-post-migration

Bourne realiza a validação funcional após a migração, comparando o comportamento do sistema migrado com o original para garantir equivalência.

## Inputs

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `operationId` | string | ID da operação |
| `originalWorkflowSamples` | array | Execuções de exemplo do n8n original |
| `migratedSystemEndpoints` | object | Endpoints do sistema migrado |

## Execução

1. **Comparação de outputs:**
   - Executar o mesmo input nos dois sistemas
   - Comparar outputs campo a campo
   - Documentar diferenças aceitáveis vs bloqueantes

2. **Validação de triggers:**
   - Confirmar que webhooks do sistema novo recebem eventos
   - Confirmar que schedules ativam nos horários corretos

3. **Validação de dados:**
   - Verificar que todos os campos esperados estão presentes
   - Confirmar transformações de dados produzem resultados corretos

4. **Validação de credenciais:**
   - Confirmar que autenticações funcionam em produção

5. **Validação de error handling:**
   - Simular falha de API e verificar comportamento

## Critérios de Aprovação

| Critério | Requisito |
|----------|-----------|
| Equivalência funcional | 100% dos cenários testados passam |
| Performance | Tempo de execução ≤ 120% do original |
| Data integrity | Zero diferença em campos críticos |
| Error handling | Falhas tratadas conforme especificado |

## Output

```yaml
postMigrationValidation:
  status: APPROVED | FAILED
  tests:
    functional: 12/12 passed
    performance: avg 2.3s (original: 2.1s) — ACCEPTABLE
    dataIntegrity: 100% match
    errorHandling: PASS
  issues: []
  recommendation: "Aprovado para desativar n8n original após 48h de observação"
```
