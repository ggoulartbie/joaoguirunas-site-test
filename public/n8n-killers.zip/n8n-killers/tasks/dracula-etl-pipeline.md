---
task: ETL Pipeline for High Volume
agent: dracula
elicit: true
---

# dracula-etl-pipeline

Drácula projeta e implementa pipelines ETL para automações que processam grandes volumes de dados, com paginação, chunking e controle de throughput.

## Inputs

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `sourceApi` | string | API de origem dos dados |
| `targetApi` | string | API de destino |
| `estimatedVolume` | number | Volume estimado de registros |
| `schemaMap` | object | Mapeamento de schemas |

## Elicitação

```
? Volume estimado de registros por execução? ___
? A API de origem tem paginação? (Y/n)
  ? Tipo de paginação:
    > cursor-based (next_cursor)
      page-based (?page=N)
      offset-based (?offset=N&limit=L)
? Há rate limit na API? (Y/n)
  ? Limite: ___ requests por ___ segundos
? Processamento em batch ou registro por registro?
  > batch (mais eficiente)
    individual (mais controle)
```

## Padrões ETL Implementados

### Paginação Cursor-Based

```javascript
// Code node — Loop de paginação com cursor
let allItems = [];
let cursor = null;

do {
  const url = cursor
    ? `https://api.source.com/data?cursor=${cursor}&limit=100`
    : `https://api.source.com/data?limit=100`;

  const response = await this.helpers.httpRequest({ method: 'GET', url });
  allItems = allItems.concat(response.data);
  cursor = response.next_cursor;
} while (cursor);

return allItems.map(item => ({ json: item }));
```

### Rate Limiting com Delay

```javascript
// Throttle: máx 10 requests/segundo
const RATE_LIMIT = 10;
const INTERVAL_MS = 1000;

async function throttledRequest(items) {
  const chunks = [];
  for (let i = 0; i < items.length; i += RATE_LIMIT) {
    chunks.push(items.slice(i, i + RATE_LIMIT));
  }

  const results = [];
  for (const chunk of chunks) {
    const chunkResults = await Promise.all(chunk.map(processItem));
    results.push(...chunkResults);
    if (chunks.indexOf(chunk) < chunks.length - 1) {
      await new Promise(r => setTimeout(r, INTERVAL_MS));
    }
  }
  return results;
}
```

### Chunking para Writes em Batch

```javascript
// Escrever em batches de 50
const BATCH_SIZE = 50;
const items = $input.all();

for (let i = 0; i < items.length; i += BATCH_SIZE) {
  const batch = items.slice(i, i + BATCH_SIZE).map(item => item.json);
  await writeBatch(batch);
}
```

## Output

- Pipeline implementado com paginação
- Rate limiting configurado
- Métricas de progresso logadas por batch
- Checkpoint/resume em caso de falha parcial
