---
task: Setup Webhooks
agent: ghostface
elicit: true
---

# ghostface-setup-webhooks

Ghostface projeta e implementa todos os webhooks necessários para a automação, com autenticação, validação de payload e idempotência.

## Elicitação

```
? Quantos webhooks a automação precisa? ___

Para cada webhook:
? Nome/propósito: ___
? Sistema que vai enviar o evento: ___
? Método HTTP: POST | GET
? O sistema suporta HMAC signature? (Y/n)
? Precisa de resposta imediata (sync) ou pode processar em background (async)?
  > async (resposta 200 imediata, processa depois)
    sync (espera processamento para responder)
```

## Execução

### 1. Definir URL Structure

```
Padrão: /webhook/{operationId}/{purpose}
Exemplo: /webhook/op-001/customer-created
```

### 2. Implementar Validação de Payload

```javascript
// Code node de validação (antes de qualquer processamento)
const Ajv = require('ajv');
const ajv = new Ajv();

const schema = {
  type: 'object',
  required: ['event', 'data'],
  properties: {
    event: { type: 'string', enum: ['customer.created', 'customer.updated'] },
    data: {
      type: 'object',
      required: ['id', 'email'],
      properties: {
        id: { type: 'string' },
        email: { type: 'string', format: 'email' }
      }
    },
    timestamp: { type: 'number' }
  }
};

const validate = ajv.compile(schema);
const valid = validate($json.body);

if (!valid) {
  throw new Error(`Invalid payload: ${ajv.errorsText(validate.errors)}`);
}

return [{ json: $json.body }];
```

### 3. Verificação HMAC

```javascript
const crypto = require('crypto');
const rawBody = $json.rawBody;
const signature = $json.headers['x-signature'];
const secret = $env.WEBHOOK_SECRET;

const computed = crypto.createHmac('sha256', secret)
  .update(rawBody).digest('hex');

if (`sha256=${computed}` !== signature) {
  throw new Error('[ghostface] Webhook signature invalid — request rejected');
}
```

### 4. Idempotência

```javascript
// Usando o ID do evento como chave de deduplicação
const eventId = $json.body.event_id || $json.headers['x-event-id'];
// Verificar em cache/DB se já processado
// Se sim: return [] (ignorar silenciosamente)
// Se não: marcar como processado e continuar
```

## Output

```yaml
webhooks:
  - name: "Customer Created"
    url: "/webhook/op-001/customer-created"
    method: POST
    auth: hmac-sha256
    validation: schema-defined
    idempotency: event-id-header
    responseMode: async
    status: CONFIGURED
```
