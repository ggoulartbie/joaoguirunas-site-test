---
task: Setup Error Handling
agent: amy
elicit: true
---

# amy-setup-error-handling

Amy implementa a estratégia completa de error handling para a automação: Error Triggers, retry logic, fallbacks e circuit breakers.

## Elicitação

```
? A automação é crítica para o negócio? (Y/n)
  → Se sim: alertas imediatos, retry agressivo, circuit breaker

? Quais sistemas externos são mais propensos a falhas?
  → Classificar por criticidade

? Há janela de manutenção onde falhas são aceitáveis? (Y/n)
  ? Quando: ___

? Para erros críticos, alertar via:
  [x] Slack
  [ ] Email
  [ ] PagerDuty
  [ ] Outro: ___
```

## Execução

### 1. Error Trigger Workflow

Criar workflow separado que captura erros de todos os workflows da squad:

```json
{
  "name": "n8n-killers Error Handler",
  "nodes": [
    {
      "type": "n8n-nodes-base.errorTrigger",
      "name": "On Error"
    },
    {
      "type": "n8n-nodes-base.code",
      "name": "Classify Error",
      "parameters": {
        "code": "// Classificar: transiente vs permanente\nconst error = $json.error;\nconst isTransient = [\n  'ECONNRESET', 'ETIMEDOUT', 'ECONNREFUSED',\n  '429', '503', '504'\n].some(code => error.message.includes(code));\nreturn [{ json: { ...error, isTransient, severity: isTransient ? 'LOW' : 'HIGH' } }];"
      }
    },
    {
      "type": "n8n-nodes-base.slack",
      "name": "Alert Slack"
    }
  ]
}
```

### 2. Retry Logic por Node

```yaml
# Configuração de retry no n8n
retryOnFail: true
maxTries: 3
waitBetweenTries: 5000  # 5 segundos, dobra a cada tentativa
```

### 3. Continue on Fail por Criticidade

| Node | continueOnFail | Motivo |
|------|---------------|--------|
| Triggers | false | Falha no trigger = operação não inicia |
| Data fetch crítico | false | Sem dados = não processar |
| Enrichment opcional | true | Dados extras — não bloquear se falhar |
| Notificação | true | Alerta falhou — não matar o fluxo principal |
| Logging | true | Log falhou — não é crítico |

### 4. Mensagem de Alerta

```
🚨 *Automation Error — n8n Killers*

*Workflow:* {{ $workflow.name }}
*Node:* {{ $json.error.node.name }}
*Error:* {{ $json.error.message }}
*Time:* {{ $now.toFormat('dd/MM/yyyy HH:mm:ss') }}
*Execution:* {{ $execution.id }}

{{ if $json.isTransient }}⚠️ Transient error — will retry automatically{{ else }}❌ Permanent error — manual intervention required{{ endif }}

<{{ $env.N8N_URL }}/workflow/executions/{{ $execution.id }}|View execution>
```

## Output

- Error Trigger workflow criado e ativo
- Retry configurado em cada node crítico
- continueOnFail definido por node
- Alerta de Slack testado e funcionando
