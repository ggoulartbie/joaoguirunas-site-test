---
task: Create Automation via API
agent: lisbeth
elicit: true
---

# lisbeth-create-automation

Lisbeth cria automações completas programaticamente via n8n REST API, ou implementa a automação no sistema-alvo usando suas APIs nativas.

## Elicitação

```
? Modo de criação:
  > via n8n API (criar workflow no n8n via API)
    via Make API (criar cenário no Make via API)
    implementação direta (código Node.js)

? Spec de automação disponível? (Y/n)
  ? Path: ___
```

## Execução — Via n8n API

### 1. Criar Workflow

```bash
POST https://n8n.company.com/api/v1/workflows
Authorization: Bearer {N8N_API_KEY}
Content-Type: application/json

{
  "name": "Customer Sync Automation",
  "nodes": [...],
  "connections": {...},
  "settings": {
    "executionOrder": "v1",
    "saveManualExecutions": true,
    "callerPolicy": "workflowsFromSameOwner"
  },
  "staticData": null,
  "tags": ["n8n-killers", "customer-sync"]
}
```

### 2. Ativar Workflow

```bash
PATCH https://n8n.company.com/api/v1/workflows/{id}
Authorization: Bearer {N8N_API_KEY}

{ "active": true }
```

### 3. Executar Manualmente (teste)

```bash
POST https://n8n.company.com/api/v1/workflows/{id}/execute
Authorization: Bearer {N8N_API_KEY}

{
  "startNodes": ["Webhook Trigger"],
  "destinationNode": "Send Slack Notification"
}
```

### 4. Monitorar Execução

```bash
GET https://n8n.company.com/api/v1/executions
Authorization: Bearer {N8N_API_KEY}
?workflowId={id}&status=running&limit=10
```

## Execução — Via Make API

```bash
# Criar cenário
POST https://www.make.com/api/v2/scenarios
Authorization: Token {MAKE_API_KEY}

# Ativar cenário
PATCH https://www.make.com/api/v2/scenarios/{id}
{ "isEnabled": true }
```

## Output

```yaml
automationCreated:
  system: n8n
  workflowId: "abc123"
  name: "Customer Sync Automation"
  status: active
  webhookUrl: "https://n8n.company.com/webhook/xyz"
  createdAt: "2026-04-14T15:00:00Z"
```
