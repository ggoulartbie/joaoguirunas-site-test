# Workflow Analysis Report

**Operação:** {operationId}
**Analista:** Hannibal Lecter
**Data:** {date}
**Arquivo analisado:** {filename}

---

## Metadados do Workflow

| Campo | Valor |
|-------|-------|
| Nome | {workflow.name} |
| ID | {workflow.id} |
| Ativo | {workflow.active} |
| Criado em | {workflow.createdAt} |
| Atualizado em | {workflow.updatedAt} |
| Total de nodes | {nodes.count} |
| Total de triggers | {triggers.count} |
| Credenciais usadas | {credentials.count} |

---

## Inventário de Nodes

| # | Nome | Tipo | Categoria | Credencial | Criticidade |
|---|------|------|-----------|-----------|-------------|
{nodes_table}

---

## Grafo de Fluxo

```
{flow_diagram}
```

---

## Triggers Identificados

{triggers_section}

---

## Credenciais Necessárias

| Nome | Tipo | Sistema | Scope |
|------|------|---------|-------|
{credentials_table}

---

## Expressões Complexas

Expressões JavaScript não triviais que requerem atenção na migração:

{expressions_section}

---

## Sub-workflows Referenciados

{subworkflows_section}

---

## Riscos & Pontos de Atenção

| Severidade | Node | Issue | Recomendação |
|-----------|------|-------|-------------|
{risks_table}

---

## Resumo para Migração

- **Complexidade estimada:** BAIXA / MÉDIA / ALTA
- **Nodes com equivalente direto:** {X}/{total}
- **Nodes que precisam de workaround:** {Y}
- **Nodes sem equivalente:** {Z}
- **Recomendação:** {recommendation}

---

*Gerado por Hannibal Lecter — n8n Killers Squad*
