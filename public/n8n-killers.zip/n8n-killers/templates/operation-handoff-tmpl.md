# Operation Handoff

**ID:** {operationId}
**Orquestrador:** Dexter Morgan
**Data de Conclusão:** {date}
**Tipo:** migration / new-automation
**Sistema-alvo:** {target_system}

---

## Resultado Final

**Status:** ✅ CONCLUÍDO / ❌ FALHOU / ⚠️ CONCLUÍDO COM RESSALVAS

**Verdict QA:** {anton_verdict}
**Duração total:** {duration}

---

## O que Foi Feito

| Agente | Task | Status | Output |
|--------|------|--------|--------|
| Hannibal | Análise do workflow | ✅ | workflow-analysis-report.md |
| Bourne | Assessment de migração | ✅ | migration-assessment.md |
| Drácula | Mapeamento de dados | ✅ | data-schema-map.yaml |
| Villanelle | Credenciais configuradas | ✅ | credentials configuradas |
| Ghostface | Triggers migrados | ✅ | triggers-config.yaml |
| Lisbeth | Implementação | ✅ | automation ativa |
| Amy | Error handling | ✅ | error-workflow ativo |
| Anton | Validação QA | ✅ | PASS |

---

## Arquivos Gerados

| Arquivo | Localização | Descrição |
|---------|------------|-----------|
{files_table}

---

## Automação Entregue

| Campo | Valor |
|-------|-------|
| Sistema | {target_system} |
| ID da automação | {automation_id} |
| URL de acesso | {automation_url} |
| Status | ACTIVE |
| Monitoring | {monitoring_dashboard} |
| Alertas | {alert_channel} |

---

## Issues Conhecidas / Tech Debt

{issues_section}

---

## Próximos Passos Recomendados

- [ ] {next_step_1}
- [ ] {next_step_2}
- [ ] Monitorar por 48h e verificar métricas com Amy
- [ ] Desativar workflow n8n original após validação em prod (se migration)

---

## Credenciais & Segurança

- Credenciais configuradas: {credentials_count}
- Auditoria de segurança: {security_audit_status}
- Data de expiração mais próxima: {next_credential_expiry}
- Responsável por rotação: @villanelle

---

## Contatos

| Role | Agente | Para |
|------|--------|------|
| Orquestrador | @dexter | Questões gerais |
| Análise n8n | @hannibal | Dúvidas sobre workflow original |
| Dados | @dracula | Transformações e schema |
| API/Código | @lisbeth | Integração e bugs |
| Segurança | @villanelle | Credenciais e auth |
| Eventos | @ghostface | Webhooks e triggers |
| Incidentes | @amy | Falhas e monitoramento |
| QA | @anton | Regressão e novos testes |

---

*Operação encerrada por Dexter Morgan — n8n Killers Squad*
