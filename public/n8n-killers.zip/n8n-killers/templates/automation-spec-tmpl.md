# Automation Specification

**Operação:** {operationId}
**Designer:** V
**Data:** {date}

---

## Visão Geral

**Nome:** {automation_name}
**Objetivo:** {objective}
**Padrão Arquitetural:** Trigger-Process-Action / Fan-out / Fan-in / ETL

---

## Trigger

| Campo | Valor |
|-------|-------|
| Tipo | webhook / schedule / manual |
| Fonte | {source_system} |
| Evento | {event_name} |
| Frequência | {frequency} (se schedule) |
| URL | {webhook_url} (se webhook) |
| Auth | {auth_type} |

---

## Fluxo Principal

```
{flow_diagram}
```

---

## Nodes Necessários

| # | Nome | Tipo n8n | Propósito | Credencial | continueOnFail |
|---|------|---------|-----------|-----------|---------------|
{nodes_table}

---

## Transformações de Dados

| Ponto | Campo Entrada | Transformação | Campo Saída |
|-------|--------------|--------------|------------|
{transformations_table}

---

## Sistemas Externos

| Sistema | Operações | Auth | Rate Limit |
|---------|-----------|------|-----------|
{systems_table}

---

## Sub-workflows

{subworkflows_section}

---

## Error Handling

| Node | Estratégia | Retry | Alerta |
|------|-----------|-------|--------|
{error_handling_table}

---

## Requisitos Não-Funcionais

| Requisito | Valor |
|----------|-------|
| SLA | {sla} |
| Tempo máx de execução | {max_exec_time} |
| Volume esperado | {volume} |
| Disponibilidade | {availability} |

---

## Credenciais Necessárias

{credentials_section}

---

## Variáveis de Ambiente

{env_vars_section}

---

## Critérios de Aceite

- [ ] {acceptance_criteria_1}
- [ ] {acceptance_criteria_2}
- [ ] {acceptance_criteria_3}
- [ ] Testes de Anton: PASS
- [ ] Auditoria de Villanelle: PASS

---

*Gerado por V — n8n Killers Squad*
