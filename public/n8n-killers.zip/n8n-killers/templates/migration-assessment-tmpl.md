# Migration Assessment

**Operação:** {operationId}
**Estrategista:** Jason Bourne
**Data:** {date}
**Sistema-alvo:** {target_system}

---

## Score de Compatibilidade

```
Score: {score}%

████████████░░░ 87%
▲ Equivalente direto: {direct}%
▲ Adapt/workaround: {adapt}%
▼ Sem equivalente: {incompatible}%
```

| Classificação | Quantidade | % |
|--------------|-----------|---|
| EQUIVALENT (sem modificação) | {n} | {%} |
| ADAPT (leve modificação) | {n} | {%} |
| WORKAROUND (solução alternativa) | {n} | {%} |
| INCOMPATIBLE (sem solução) | {n} | {%} |

---

## Estratégia de Migração

**Abordagem escolhida:** BIG BANG / INCREMENTAL / PARALLEL RUN

**Justificativa:** {rationale}

### Sequência de Migração

| Fase | O que migrar | Dependências | Estimativa |
|------|-------------|-------------|------------|
{phases_table}

---

## Gaps e Incompatibilidades

{gaps_section}

---

## Riscos da Migração

| Risco | Probabilidade | Impacto | Mitigação |
|-------|--------------|---------|-----------|
{risks_table}

---

## Plano de Rollback

**Janela de rollback:** {X} horas após cutover

**Procedimento:**
1. {step_1}
2. {step_2}
3. {step_3}

**Trigger para rollback:**
- Taxa de erro > {threshold}%
- Downtime > {minutes} minutos
- Dados corrompidos detectados

---

## Atualizações Necessárias nos Sistemas-Fonte

| Sistema | O que atualizar | Responsável |
|---------|----------------|-------------|
{updates_table}

---

## Aprovação

- [ ] Estratégia aprovada por @dexter
- [ ] Janela de migração confirmada com stakeholders
- [ ] Rollback plan revisado

---

*Gerado por Jason Bourne — n8n Killers Squad*
