# Coding Standards — n8n Killers Squad

## Princípios Gerais

- **Task-first**: Cada operação é definida por uma task. Nenhum agente improvisa.
- **Documentar sempre**: Cada decisão tomada vai no operation-handoff.
- **Zero invenção**: Só implementa o que foi especificado no design.
- **Validação obrigatória**: Anton valida antes de qualquer entrega.

## JavaScript / TypeScript

- ES2020+ (async/await, optional chaining, nullish coalescing)
- Sem `var` — usar `const` e `let`
- Funções puras sempre que possível
- Error handling explícito com mensagens descritivas
- Tipagem TypeScript para custom nodes

```javascript
// CORRETO
const result = await fetchData(url).catch(err => {
  throw new Error(`Failed to fetch ${url}: ${err.message}`);
});

// ERRADO
let result = fetchData(url); // sem await, sem error handling
```

## Expressões n8n

- Usar `{{ $json.field }}` para acessar dados do item atual
- Usar `{{ $node["NodeName"].json.field }}` para dados de nodes anteriores
- Usar `{{ $workflow.id }}` para metadados do workflow
- Evitar lógica complexa em expressões — usar Code node

## Nomenclatura

| Tipo | Padrão | Exemplo |
|------|--------|---------|
| Tasks | `{agente}-{acao}.md` | `lisbeth-discover-api.md` |
| Workflows | `{ciclo}.yaml` | `migration-cycle.yaml` |
| Templates | `{tipo}-tmpl.md` | `workflow-analysis-report-tmpl.md` |
| Agents | `{nome}/MEMORY.md` | `dexter/MEMORY.md` |

## Documentação de Operações

Todo handoff de operação deve conter:
- ID da operação
- Tipo (migration | new-automation)
- Sistema-alvo
- Agentes acionados e outputs
- Issues encontradas
- Status final

## Error Messages

```javascript
// Padrão de mensagem de erro
throw new Error(`[${agentId}] ${operation} failed: ${reason}. Context: ${JSON.stringify(context)}`);
```

## Segurança

- **NUNCA** logar credenciais ou tokens
- Mascarar campos sensíveis em logs: `password`, `token`, `secret`, `key`
- Validar payloads de webhooks antes de processar
- Verificar HMAC signature quando disponível
