# Tech Stack — n8n Killers Squad

## Plataforma de Automação

| Tecnologia | Versão | Uso |
|-----------|--------|-----|
| n8n | >= 1.0 | Plataforma de origem para migração |
| Node.js | >= 18 | Runtime para custom nodes e scripts |
| TypeScript | >= 5.0 | Desenvolvimento de custom nodes |

## Integração & HTTP

| Tecnologia | Uso |
|-----------|-----|
| axios | HTTP client para chamadas de API |
| node-fetch | Fetch API nativa |
| REST APIs | Integração com sistemas externos |
| GraphQL | Quando suportado pelo sistema-alvo |

## Transformação de Dados

| Tecnologia | Uso |
|-----------|-----|
| jsonpath-plus | Querying de JSON complexo |
| luxon | Operações de data/hora |
| ajv | JSON Schema validation |
| lodash | Utilitários de dados |

## Autenticação & Segurança

| Tecnologia | Uso |
|-----------|-----|
| OAuth2 | Autenticação de APIs |
| JWT | Token-based auth |
| HMAC SHA256 | Webhook signature verification |
| dotenv | Gerenciamento de env vars |

## Configuração & YAML

| Tecnologia | Uso |
|-----------|-----|
| js-yaml | Parse/generate YAML |
| ajv | Schema validation de manifests |

## Sistemas-Alvo Suportados

| Sistema | Tipo |
|---------|------|
| Make (Integromat) | Plataforma de automação |
| Zapier | Plataforma de automação |
| Pipedream | Plataforma de automação |
| Código customizado (Node.js) | Implementação direta |
| APIs REST genéricas | Qualquer API com documentação |

## n8n Node Types Conhecidos

| Tipo | Exemplos |
|------|---------|
| Core Nodes | Set, IF, Switch, Merge, Split Out, Code, HTTP Request |
| Trigger Nodes | Webhook, Schedule, Email Trigger, Event |
| App Nodes | Gmail, Slack, Notion, Google Sheets, HubSpot, Salesforce |
| Sub-workflow | Execute Workflow |
| Utility | Wait, NoOp, Stop and Error, Crypto |
