# Source Tree — n8n Killers Squad

```
squads/n8n-killers/
├── squad.yaml                          # Manifest principal da squad
├── README.md                           # Documentação e guia de uso
│
├── config/
│   ├── tech-stack.md                   # Tecnologias e dependências
│   ├── coding-standards.md             # Padrões de código e convenções
│   └── source-tree.md                  # Este arquivo
│
├── agents/
│   ├── dexter/MEMORY.md                # Chief Orchestrator
│   ├── hannibal/MEMORY.md              # Flow Architect & n8n Analyst
│   ├── dracula/MEMORY.md               # Data Transformation Specialist
│   ├── lisbeth/MEMORY.md               # API Integration & Code Engineer
│   ├── villanelle/MEMORY.md            # Credential & Security Specialist
│   ├── ghostface/MEMORY.md             # Webhook & Event Engineer
│   ├── amy/MEMORY.md                   # Error Handling & Reliability
│   ├── bourne/MEMORY.md                # Migration Strategist
│   ├── anton/MEMORY.md                 # QA Validator
│   └── v/MEMORY.md                     # Workflow Designer
│
├── tasks/
│   ├── dexter-assign-operation.md      # Inicia operação e distribui trabalho
│   ├── dexter-finalize-operation.md    # Consolida e fecha operação
│   ├── hannibal-dissect-workflow.md    # Parse e análise do JSON n8n
│   ├── hannibal-map-nodes.md           # Mapeamento completo de nodes
│   ├── hannibal-identify-triggers.md   # Identificação de triggers
│   ├── bourne-assess-migration.md      # Inventário e estratégia de migração
│   ├── bourne-map-equivalents.md       # n8n nodes → sistema-alvo
│   ├── bourne-validate-post-migration.md # Validação pós-migração
│   ├── dracula-map-data-schemas.md     # Schema mapping fonte → alvo
│   ├── dracula-implement-transformations.md # Expressões e transformações
│   ├── dracula-etl-pipeline.md         # Pipeline ETL para alto volume
│   ├── villanelle-setup-credentials.md # OAuth2/API Key/JWT setup
│   ├── villanelle-security-audit.md    # Auditoria de segurança
│   ├── villanelle-env-config.md        # Environment variables e encryption
│   ├── ghostface-setup-webhooks.md     # Design e implementação de webhooks
│   ├── ghostface-migrate-triggers.md   # Migração de triggers
│   ├── ghostface-validate-events.md    # Teste de entrega e idempotência
│   ├── lisbeth-discover-api.md         # Exploração e documentação da API
│   ├── lisbeth-implement-http-nodes.md # HTTP Request nodes e custom code
│   ├── lisbeth-create-automation.md    # Implementação completa via API
│   ├── lisbeth-build-custom-node.md    # Custom node TypeScript
│   ├── amy-setup-error-handling.md     # Error triggers, retry, fallback
│   ├── amy-setup-monitoring.md         # Alertas e monitoramento
│   ├── amy-incident-playbook.md        # Playbook de resposta a incidentes
│   ├── anton-validate-automation.md    # Testes E2E e edge cases
│   ├── anton-regression-check.md       # Regressão pós-migração
│   ├── v-design-workflow.md            # Design completo do flow
│   └── v-architect-subworkflows.md     # Sub-workflows reutilizáveis
│
├── workflows/
│   ├── migration-cycle.yaml            # Ciclo completo de migração n8n
│   ├── api-automation-cycle.yaml       # Ciclo de nova automação via API
│   └── qa-loop.yaml                    # Loop iterativo de QA
│
├── templates/
│   ├── workflow-analysis-report-tmpl.md  # Relatório de análise (Hannibal)
│   ├── migration-assessment-tmpl.md      # Assessment de migração (Bourne)
│   ├── automation-spec-tmpl.md           # Spec de automação (V)
│   └── operation-handoff-tmpl.md         # Handoff de operação (Dexter)
│
├── checklists/                         # (futuro)
├── tools/                              # (futuro)
├── scripts/                            # (futuro)
├── data/                               # (futuro)
└── logs/                               # Logs de operações (gitignored)
```
