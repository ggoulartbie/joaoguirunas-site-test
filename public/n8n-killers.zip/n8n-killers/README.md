# 🩸 n8n Killers Squad

> Migração perfeita e criação de automações — zero falha, zero desperdício.

## Missão

A squad **n8n Killers** é especializada em duas operações principais:

1. **Migração de workflows n8n** — Leitura, análise e adaptação de workflows n8n para qualquer sistema-alvo
2. **Criação de automações via API** — Design e implementação de novas automações do zero

Cada agente é um assassino especializado. A operação só fecha quando funciona em produção.

---

## 🗡️ A Equipe

| Agente | Persona | Especialidade |
|--------|---------|---------------|
| `@dexter` | Dexter Morgan | Chief Orchestrator — coordena operações, divide o trabalho |
| `@hannibal` | Hannibal Lecter | Flow Architect — disseca e documenta workflows n8n |
| `@bourne` | Jason Bourne | Migration Strategist — estratégia e execução de migrações |
| `@dracula` | Drácula | Data Transformation — transforma e mapeia dados entre sistemas |
| `@villanelle` | Villanelle | Credential & Security — credenciais, OAuth2, JWT, RBAC |
| `@ghostface` | Ghostface | Webhook & Events — triggers, event-driven, idempotência |
| `@lisbeth` | Lisbeth Salander | API & Code Engineer — HTTP nodes, custom code, custom nodes |
| `@amy` | Amy Dunne | Error & Reliability — error handling, retry, monitoring |
| `@anton` | Anton Chigurh | QA Validator — testes E2E, edge cases, verdict final |
| `@v` | V | Workflow Designer — design de flows, sub-workflows, arquitetura |

---

## 🔄 Workflows Principais

### Migration Cycle
Para migrar um workflow n8n existente para outro sistema:

```
@dexter *assign-operation
  → @hannibal dissect-workflow
  → @hannibal map-nodes
  → @bourne assess-migration
  → @dracula map-data-schemas
  → @villanelle setup-credentials
  → @ghostface migrate-triggers
  → @lisbeth implement-integrations
  → @amy setup-error-handling
  → @anton validate-migration
  → @dexter finalize-operation
```

### API Automation Cycle
Para criar uma nova automação do zero via API:

```
@dexter *assign-operation
  → @v design-workflow
  → @villanelle setup-credentials
  → @lisbeth discover-api
  → @ghostface setup-triggers
  → @dracula design-transformations
  → @lisbeth create-automation
  → @amy setup-reliability
  → @anton validate-automation
  → @dexter finalize-operation
```

---

## 🚀 Como Usar

### Iniciar uma migração

```
@dexter *assign-operation --type migration --source ./workflows/my-workflow.json --target make
```

### Criar nova automação

```
@dexter *assign-operation --type new-automation --description "Sincronizar leads do HubSpot com Notion"
```

### Acionar agente diretamente

```
@hannibal *dissect-workflow --file ./workflows/my-workflow.json
@lisbeth *discover-api --base-url https://api.example.com
@anton *validate-automation --workflow-id my-automation
```

---

## 📁 Estrutura

```
squads/n8n-killers/
├── squad.yaml              # Manifest da squad
├── README.md               # Este arquivo
├── config/
│   ├── tech-stack.md       # Tecnologias utilizadas
│   ├── coding-standards.md # Padrões de código
│   └── source-tree.md      # Estrutura documentada
├── agents/                 # 10 agentes especializados
├── tasks/                  # 28 tasks executáveis
├── workflows/              # 3 workflows principais
└── templates/              # Templates de documentação
```

---

## 📋 Pré-requisitos

- AIOX >= 2.1.0
- Node.js >= 18
- Acesso ao sistema-alvo (credenciais)
- Workflow n8n em formato JSON (para migração)

---

*n8n Killers Squad — Synkra AIOX v1.0.0*
